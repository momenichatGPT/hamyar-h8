'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.DB_PATH || './h8.sqlite';
const COOKIE_NAME = 'h8_session';
const SESSION_DAYS = 7;
if (DB_PATH !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(DB_PATH)), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '512kb' }));
// The HTML and API are served from the same origin; cross-origin access is disabled by default.

// First release: secure account management, class roster, and server-side AI proxy.
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('دانش‌آموز','سرگروه','نماینده','معلم')),
  password_salt TEXT,
  password_hash TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS class_state (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS user_progress (user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, payload TEXT NOT NULL DEFAULT '{}', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit_logs (id TEXT PRIMARY KEY, actor_user_id TEXT, action TEXT NOT NULL, target_user_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
INSERT OR IGNORE INTO class_state(id,payload) VALUES(1,'{}');
`);

const roles = new Set(['دانش‌آموز', 'سرگروه', 'نماینده', 'معلم']);
const usernamePattern = /^[A-Za-z0-9._-]{3,40}$/;
const randomId = () => crypto.randomUUID();
const tokenHash = token => crypto.createHash('sha256').update(token).digest('hex');
const passwordHash = (password, salt) => crypto.scryptSync(password, Buffer.from(salt, 'hex'), 64).toString('hex');
function verifyPassword(password, salt, expected) {
  if (!salt || !expected) return false;
  const actual = Buffer.from(passwordHash(password, salt), 'hex');
  const target = Buffer.from(expected, 'hex');
  return actual.length === target.length && crypto.timingSafeEqual(actual, target);
}
function cleanUser(row) {
  return { id: row.id, username: row.username, name: row.name, role: row.role, passwordSet: Boolean(row.password_hash) };
}
function getCookie(req, name) {
  const raw = req.headers.cookie || '';
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i >= 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return '';
}
function requireClientHeader(req, res, next) {
  if (req.get('X-H8-Client') !== 'web') return res.status(403).json({ error: 'درخواست از کلاینت مجاز پذیرفته نشد.' });
  next();
}
function auth(req, res, next) {
  const token = getCookie(req, COOKIE_NAME);
  if (!token) return res.status(401).json({ error: 'ابتدا وارد حساب شو.' });
  const session = db.prepare(`SELECT sessions.expires_at, users.* FROM sessions JOIN users ON users.id=sessions.user_id WHERE sessions.token_hash=?`).get(tokenHash(token));
  if (!session || session.expires_at < Date.now()) {
    if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(token));
    res.clearCookie(COOKIE_NAME, cookieOptions());
    return res.status(401).json({ error: 'نشست منقضی شده است؛ دوباره وارد شو.' });
  }
  req.user = session;
  next();
}
function requireLeader(req, res, next) {
  if (req.user?.role !== 'سرگروه') return res.status(403).json({ error: 'فقط سرگروه مجاز به مدیریت حساب‌های کلاس است.' });
  next();
}
function cookieOptions() {
  const production = process.env.NODE_ENV === 'production';
  return { httpOnly: true, secure: production, sameSite: 'lax', path: '/', maxAge: SESSION_DAYS * 24 * 60 * 60 * 1000 };
}
function validateMember(body, isCreate) {
  const name = String(body.name || '').trim();
  const username = String(body.username || '').trim();
  const role = String(body.role || 'دانش‌آموز').trim();
  const password = body.password == null ? '' : String(body.password);
  if (name.length < 2 || name.length > 80) throw new Error('نام باید بین ۲ تا ۸۰ نویسه باشد.');
  if (!usernamePattern.test(username)) throw new Error('نام کاربری باید ۳ تا ۴۰ نویسه و فقط شامل حروف انگلیسی، عدد، نقطه، خط تیره یا زیرخط باشد.');
  if (!roles.has(role)) throw new Error('نقش انتخاب‌شده معتبر نیست.');
  if (isCreate && password.length < 8) throw new Error('رمز حساب جدید باید حداقل ۸ نویسه باشد.');
  if (password && password.length < 8) throw new Error('رمز عبور باید حداقل ۸ نویسه باشد.');
  return { name, username, role, password };
}

// Import the prepared 34-account roster only into an empty database. Passwords are salted scrypt hashes; plaintext passwords are never stored here.
function seedRoster() {
  if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n > 0) return;
  const seedPath = path.join(__dirname, 'h8_seed_accounts.json');
  if (fs.existsSync(seedPath)) {
    const accounts = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
    if (!Array.isArray(accounts) || accounts.length !== 34) throw new Error('فایل حساب‌های اولیه باید دقیقاً ۳۴ حساب داشته باشد.');
    const insert = db.prepare('INSERT INTO users(id,username,name,role,password_salt,password_hash) VALUES(?,?,?,?,?,?)');
    const tx = db.transaction(() => {
      for (const a of accounts) {
        if (!a.id || !usernamePattern.test(a.username) || !roles.has(a.role) || !a.salt || !a.passwordHash) throw new Error('اطلاعات یکی از حساب‌های اولیه معتبر نیست.');
        insert.run(String(a.id), String(a.username), String(a.name), String(a.role), String(a.salt), String(a.passwordHash));
      }
    });
    tx();
    console.log('Imported 34 prepared H8 accounts into the empty database.');
    return;
  }
  const adminUsername = String(process.env.ADMIN_USERNAME || '').trim();
  const adminPassword = String(process.env.ADMIN_PASSWORD || '');
  if (!adminUsername || !usernamePattern.test(adminUsername) || adminPassword.length < 12) {
    console.warn('Roster seeding paused: set ADMIN_USERNAME and ADMIN_PASSWORD (12+ characters) in .env, or provide h8_seed_accounts.json.');
    return;
  }
  const salt = crypto.randomBytes(16).toString('hex');
  db.prepare('INSERT INTO users(id,username,name,role,password_salt,password_hash) VALUES(?,?,?,?,?,?)')
    .run(randomId(), adminUsername, String(process.env.ADMIN_NAME || 'سرگروه کلاس').trim(), 'سرگروه', salt, passwordHash(adminPassword, salt));
  const add = db.prepare('INSERT INTO users(id,username,name,role,password_salt,password_hash) VALUES(?,?,?,?,NULL,NULL)');
  const tx = db.transaction(() => {
    for (let i = 1; i <= 30; i++) add.run(randomId(), `h806-${String(i).padStart(2, '0')}`, `دانش‌آموز ${String(i).padStart(2, '0')}`, 'دانش‌آموز');
    add.run(randomId(), 'namayande806', 'نماینده کلاس', 'نماینده');
    add.run(randomId(), 'teacher806a', 'معلم ۱', 'معلم');
    add.run(randomId(), 'teacher806b', 'معلم ۲', 'معلم');
  });
  tx();
}
seedRoster();

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'تلاش‌های ورود زیاد بوده است؛ ۱۵ دقیقه بعد دوباره تلاش کن.' } });
app.get('/api/health', (req, res) => res.json({ ok: true, service: 'Hamyar H8 API', version: '0.1.0', features: ['auth', 'roster', 'admin-account-management'] }));
app.post('/api/auth/login', requireClientHeader, loginLimiter, (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  const row = db.prepare('SELECT * FROM users WHERE username=? COLLATE NOCASE').get(username);
  if (!row || !verifyPassword(password, row.password_salt, row.password_hash)) return res.status(401).json({ error: 'نام کاربری یا رمز عبور درست نیست.' });
  const token = crypto.randomBytes(32).toString('base64url');
  const expires = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').run(tokenHash(token), row.id, expires, Date.now());
  res.cookie(COOKIE_NAME, token, cookieOptions());
  res.json({ user: cleanUser(row) });
});
app.post('/api/auth/logout', requireClientHeader, (req, res) => {
  const token = getCookie(req, COOKIE_NAME);
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(token));
  res.clearCookie(COOKIE_NAME, cookieOptions());
  res.json({ ok: true });
});
app.get('/api/auth/me', requireClientHeader, auth, (req, res) => res.json({ user: cleanUser(req.user) }));

app.post('/api/auth/change-password', requireClientHeader, auth, (req, res) => {
  const currentPassword = String(req.body?.currentPassword || '');
  const newPassword = String(req.body?.newPassword || '');
  if (!verifyPassword(currentPassword, req.user.password_salt, req.user.password_hash)) return res.status(400).json({ error: 'رمز فعلی درست نیست.' });
  if (newPassword.length < 12 || newPassword.length > 200) return res.status(400).json({ error: 'رمز جدید باید دست‌کم ۱۲ نویسه داشته باشد.' });
  if (newPassword === currentPassword) return res.status(400).json({ error: 'رمز جدید باید با رمز فعلی متفاوت باشد.' });
  const salt = crypto.randomBytes(16).toString('hex');
  db.prepare('UPDATE users SET password_salt=?, password_hash=? WHERE id=?').run(salt, passwordHash(newPassword, salt), req.user.id);
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(req.user.id);
  const token = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').run(tokenHash(token), req.user.id, Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000, Date.now());
  db.prepare('INSERT INTO audit_logs(id,actor_user_id,action,target_user_id) VALUES(?,?,?,?)').run(randomId(), req.user.id, 'password_changed', req.user.id);
  res.cookie(COOKIE_NAME, token, cookieOptions());
  res.json({ ok: true, message: 'رمز عبور تغییر کرد.' });
});

app.get('/api/my-progress', requireClientHeader, auth, (req, res) => {
  const row = db.prepare('SELECT payload, updated_at FROM user_progress WHERE user_id=?').get(req.user.id);
  res.json({ progress: row ? JSON.parse(row.payload) : { completedTaskIds: [] }, updatedAt: row?.updated_at || null });
});
app.put('/api/my-progress', requireClientHeader, auth, (req, res) => {
  const ids = req.body?.completedTaskIds;
  if (!Array.isArray(ids) || ids.length > 500 || ids.some(x => typeof x !== 'string' || x.length > 100)) return res.status(400).json({ error: 'وضعیت تکالیف معتبر نیست.' });
  const payload = JSON.stringify({ completedTaskIds: [...new Set(ids)] });
  db.prepare(`INSERT INTO user_progress(user_id,payload,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload, updated_at=CURRENT_TIMESTAMP`).run(req.user.id, payload);
  res.json({ ok: true });
});

app.get('/api/class/806/roster', requireClientHeader, auth, requireLeader, (req, res) => {
  const users = db.prepare('SELECT * FROM users ORDER BY CASE role WHEN \'سرگروه\' THEN 0 WHEN \'نماینده\' THEN 1 WHEN \'معلم\' THEN 2 ELSE 3 END, name COLLATE NOCASE').all().map(cleanUser);
  res.json({ users });
});
app.post('/api/class/806/roster', requireClientHeader, auth, requireLeader, (req, res) => {
  let data;
  try { data = validateMember(req.body, true); } catch (e) { return res.status(400).json({ error: e.message }); }
  if (data.role === 'سرگروه') return res.status(403).json({ error: 'ایجاد سرگروه جدید از این پنل مجاز نیست؛ فقط مدیر کل فعلی اختیار مدیریت سامانه را دارد.' });
  const salt = crypto.randomBytes(16).toString('hex');
  try {
    const id = randomId();
    db.prepare('INSERT INTO users(id,username,name,role,password_salt,password_hash) VALUES(?,?,?,?,?,?)').run(id, data.username, data.name, data.role, salt, passwordHash(data.password, salt));
    db.prepare('INSERT INTO audit_logs(id,actor_user_id,action,target_user_id) VALUES(?,?,?,?)').run(randomId(), req.user.id, 'account_created', id);
    res.status(201).json({ user: cleanUser(db.prepare('SELECT * FROM users WHERE id=?').get(id)) });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'این نام کاربری قبلاً ثبت شده است.' });
    throw e;
  }
});
app.put('/api/class/806/roster/:id', requireClientHeader, auth, requireLeader, (req, res) => {
  let data;
  try { data = validateMember(req.body, false); } catch (e) { return res.status(400).json({ error: e.message }); }
  const existing = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'حساب پیدا نشد.' });
  if (existing.role !== 'سرگروه' && data.role === 'سرگروه') return res.status(403).json({ error: 'تبدیل حساب به مدیر کل از این پنل مجاز نیست.' });
  if (existing.id === req.user.id && data.role !== 'سرگروه') return res.status(400).json({ error: 'نمی‌توانی نقش سرگروه حساب خودت را حذف کنی.' });
  if (existing.role === 'سرگروه' && data.role !== 'سرگروه' && db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='سرگروه'").get().n <= 1) return res.status(400).json({ error: 'کلاس باید دست‌کم یک سرگروه داشته باشد.' });
  try {
    if (data.password) {
      const salt = crypto.randomBytes(16).toString('hex');
      db.prepare('UPDATE users SET name=?,username=?,role=?,password_salt=?,password_hash=? WHERE id=?').run(data.name, data.username, data.role, salt, passwordHash(data.password, salt), existing.id);
    } else db.prepare('UPDATE users SET name=?,username=?,role=? WHERE id=?').run(data.name, data.username, data.role, existing.id);
    db.prepare('INSERT INTO audit_logs(id,actor_user_id,action,target_user_id) VALUES(?,?,?,?)').run(randomId(), req.user.id, data.password ? 'account_updated_password_reset' : 'account_updated', existing.id);
    res.json({ user: cleanUser(db.prepare('SELECT * FROM users WHERE id=?').get(existing.id)) });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'این نام کاربری قبلاً ثبت شده است.' });
    throw e;
  }
});
app.delete('/api/class/806/roster/:id', requireClientHeader, auth, requireLeader, (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'حساب پیدا نشد.' });
  if (target.id === req.user.id) return res.status(400).json({ error: 'برای جلوگیری از قفل‌شدن کلاس، حساب سرگروه خودش را حذف نکن.' });
  if (target.role === 'سرگروه' && db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='سرگروه'").get().n <= 1) return res.status(400).json({ error: 'کلاس باید دست‌کم یک سرگروه داشته باشد.' });
  db.prepare('INSERT INTO audit_logs(id,actor_user_id,action,target_user_id) VALUES(?,?,?,?)').run(randomId(), req.user.id, 'account_deleted', target.id);
  db.prepare('DELETE FROM users WHERE id=?').run(target.id);
  res.json({ ok: true });
});

// Shared class data lives in SQLite, not in each browser's localStorage.
const sharedStateKeys = new Set(['tasks','tests','groupChat','announcements','files','attendance','grades','schedule']);
app.get('/api/state', requireClientHeader, auth, (req, res) => {
  const row = db.prepare('SELECT payload, updated_at FROM class_state WHERE id=1').get();
  const all = JSON.parse(row?.payload || '{}');
  const isAdmin = req.user.role === 'سرگروه';
  const state = {};
  for (const key of ['tasks','tests','groupChat','announcements','files','schedule']) state[key] = all[key] ?? (key === 'schedule' ? null : []);
  if (isAdmin) { state.attendance = all.attendance || {}; state.grades = all.grades || []; }
  res.json({ state, updatedAt: row?.updated_at || null });
});
app.put('/api/state', requireClientHeader, auth, requireLeader, (req, res) => {
  const payload = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : null;
  if (!payload) return res.status(400).json({ error: 'ساختار اطلاعات معتبر نیست.' });
  const row = db.prepare('SELECT payload FROM class_state WHERE id=1').get();
  const current = JSON.parse(row?.payload || '{}');
  for (const [key, value] of Object.entries(payload)) {
    if (!sharedStateKeys.has(key)) continue;
    if (JSON.stringify(value).length > 300000) return res.status(413).json({ error: 'حجم این بخش بیش از حد مجاز است.' });
    current[key] = value;
  }
  db.prepare("UPDATE class_state SET payload=?, updated_at=CURRENT_TIMESTAMP WHERE id=1").run(JSON.stringify(current));
  res.json({ ok: true, updatedAt: db.prepare('SELECT updated_at FROM class_state WHERE id=1').get().updated_at });
});
app.post('/api/group-chat', requireClientHeader, auth, (req, res) => {
  const text = String(req.body?.text || '').trim();
  if (!text || text.length > 1500) return res.status(400).json({ error: 'پیام باید بین ۱ تا ۱۵۰۰ نویسه باشد.' });
  const row = db.prepare('SELECT payload FROM class_state WHERE id=1').get();
  const current = JSON.parse(row?.payload || '{}');
  const messages = Array.isArray(current.groupChat) ? current.groupChat : [];
  messages.push({ id: randomId(), author: req.user.name, username: req.user.username, text, createdAt: new Date().toISOString() });
  current.groupChat = messages.slice(-200);
  db.prepare("UPDATE class_state SET payload=?, updated_at=CURRENT_TIMESTAMP WHERE id=1").run(JSON.stringify(current));
  res.status(201).json({ ok: true, message: current.groupChat[current.groupChat.length - 1] });
});

// Serve the responsive H8 interface from the same origin as its authenticated API.
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((err, req, res, next) => {
  console.error(err.message);
  if (res.headersSent) return next(err);
  const status = err.message?.includes('مبدأ') ? 403 : 500;
  res.status(status).json({ error: status === 403 ? err.message : 'خطای داخلی سرور.' });
});
app.listen(PORT, () => console.log(`Hamyar H8 API listening on port ${PORT}`));
